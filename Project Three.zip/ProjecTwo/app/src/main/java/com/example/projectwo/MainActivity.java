package com.example.projectwo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        gridView = findViewById(R.id.gridView);

        displayData();
    }

    private void displayData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, null, null, null, null, null, null);

        String[] from = {DatabaseHelper.COL_USERNAME, DatabaseHelper.COL_PASSWORD};
        int[] to = {R.id.textViewUsername, R.id.textViewPassword};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.grid_item, cursor, from, to, 0);
        gridView.setAdapter(adapter);
    }
}
