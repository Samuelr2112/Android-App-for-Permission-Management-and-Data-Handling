package com.example.projectwo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private RecyclerView dataRecyclerView;
    private Button addDataButton;
    private DataAdapter dataAdapter;
    private List<String> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dataRecyclerView = findViewById(R.id.data_grid);
        addDataButton = findViewById(R.id.add_data_button);

        dataList = new ArrayList<>();
        dataAdapter = new DataAdapter(dataList);

        dataRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        dataRecyclerView.setAdapter(dataAdapter);

        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle adding data logic here
                dataList.add("New Data");
                dataAdapter.notifyDataSetChanged();
            }
        });
    }
}
